(() => {
  'use strict';

  /* ---------- Theme ---------- */
  const root = document.documentElement;
  const THEME_KEY = 'fathom-theme';
  const DEFAULT_THEME = root.getAttribute('data-default-theme') || 'light';

  function applyTheme(theme){
    root.setAttribute('data-theme', theme);
    document.querySelectorAll('.theme-toggle').forEach(btn=>{
      btn.setAttribute('aria-pressed', theme === 'dark');
    });
  }
  function getStoredTheme(){
    try { return localStorage.getItem(THEME_KEY); } catch(e){ return null; }
  }
  function storeTheme(t){
    try { localStorage.setItem(THEME_KEY, t); } catch(e){}
  }
  const initial = getStoredTheme() || DEFAULT_THEME;
  applyTheme(initial);

  document.addEventListener('click', (e)=>{
    const btn = e.target.closest('.theme-toggle');
    if(!btn) return;
    const current = root.getAttribute('data-theme');
    const next = current === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    storeTheme(next);
  });

  /* ---------- Loader ---------- */
  window.addEventListener('load', ()=>{
    const loader = document.querySelector('.loader');
    if(loader){ setTimeout(()=> loader.classList.add('done'), 350); }
  });

  /* ---------- Mobile nav ---------- */
  document.addEventListener('click', (e)=>{
    if(e.target.closest('.burger')){
      document.querySelector('.mobile-drawer')?.classList.add('open');
    }
    if(e.target.closest('.mobile-close') || (e.target.closest('.mobile-drawer') && e.target.tagName === 'A')){
      document.querySelector('.mobile-drawer')?.classList.remove('open');
    }
  });

  /* ---------- Scroll reveal (bidirectional) ---------- */
  const revealEls = document.querySelectorAll('.reveal, .reveal-left, .reveal-right, .reveal-scale');
  revealEls.forEach((el,i)=> el.style.setProperty('--i', i % 8));

  if('IntersectionObserver' in window){
    const io = new IntersectionObserver((entries)=>{
      entries.forEach(entry=>{
        entry.target.classList.toggle('is-in', entry.isIntersecting);
      });
    }, { threshold: 0.18, rootMargin: '0px 0px -8% 0px' });
    revealEls.forEach(el=> io.observe(el));
  } else {
    revealEls.forEach(el=> el.classList.add('is-in'));
  }

  /* ---------- Sounding line: scroll progress + depth reading ---------- */
  const rail = document.querySelector('.sounding-line');
  if(rail){
    const fill = rail.querySelector('.fill');
    const reading = rail.querySelector('.reading');
    const maxFathoms = 40;
    const onScroll = ()=>{
      const doc = document.documentElement;
      const scrolled = doc.scrollTop || document.body.scrollTop;
      const height = (doc.scrollHeight - doc.clientHeight) || 1;
      const pct = Math.min(1, Math.max(0, scrolled / height));
      fill.style.height = (pct*100) + '%';
      if(reading){ reading.textContent = (pct*maxFathoms).toFixed(1) + ' FATHOMS'; }
    };
    document.addEventListener('scroll', onScroll, { passive:true });
    onScroll();
  }

  /* ---------- Animated counters ---------- */
  const counters = document.querySelectorAll('[data-count]');
  if(counters.length){
    const cio = new IntersectionObserver((entries)=>{
      entries.forEach(entry=>{
        if(!entry.isIntersecting) return;
        const el = entry.target;
        if(el.dataset.done) return;
        el.dataset.done = '1';
        const target = parseFloat(el.getAttribute('data-count'));
        const suffix = el.getAttribute('data-suffix') || '';
        const decimals = (el.getAttribute('data-count').split('.')[1] || '').length;
        const dur = 1600;
        const start = performance.now();
        function tick(now){
          const p = Math.min(1, (now-start)/dur);
          const eased = 1 - Math.pow(1-p, 3);
          el.textContent = (target*eased).toFixed(decimals) + suffix;
          if(p < 1) requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
      });
    }, { threshold: 0.5 });
    counters.forEach(el=> cio.observe(el));
  }

  /* ---------- Portfolio filter ---------- */
  const filterRow = document.querySelector('.filter-row');
  if(filterRow){
    filterRow.addEventListener('click', (e)=>{
      const pill = e.target.closest('.filter-pill');
      if(!pill) return;
      filterRow.querySelectorAll('.filter-pill').forEach(p=>p.classList.remove('active'));
      pill.classList.add('active');
      const cat = pill.getAttribute('data-filter');
      document.querySelectorAll('.port-card').forEach(card=>{
        const match = cat === 'all' || card.getAttribute('data-cat') === cat;
        card.style.display = match ? '' : 'none';
      });
    });
  }

  /* ---------- Cursor glow (desktop) ---------- */
  const glow = document.querySelector('.cursor-glow');
  if(glow && window.matchMedia('(min-width:960px)').matches){
    let raf = null;
    document.addEventListener('mousemove', (e)=>{
      glow.classList.add('active');
      if(raf) return;
      raf = requestAnimationFrame(()=>{
        glow.style.setProperty('--x', e.clientX + 'px');
        glow.style.setProperty('--y', e.clientY + 'px');
        raf = null;
      });
    });
    document.addEventListener('mouseleave', ()=> glow.classList.remove('active'));
  }

  /* ---------- Header shrink on scroll ---------- */
  const header = document.querySelector('.site-header');
  if(header){
    let last = 0;
    document.addEventListener('scroll', ()=>{
      const y = window.scrollY;
      header.style.boxShadow = y > 8 ? 'var(--shadow-sm)' : 'none';
      last = y;
    }, { passive:true });
  }

  /* ---------- Tilt cards (cursor-tracked 3D) ---------- */
  if(window.matchMedia('(hover:hover)').matches){
    document.querySelectorAll('.tilt').forEach(card=>{
      const inner = card.querySelector('.tilt-inner') || card;
      card.addEventListener('mousemove', (e)=>{
        const r = card.getBoundingClientRect();
        const px = (e.clientX - r.left) / r.width - 0.5;
        const py = (e.clientY - r.top) / r.height - 0.5;
        inner.style.setProperty('--rx', (px * 10).toFixed(2) + 'deg');
        inner.style.setProperty('--ry', (py * -10).toFixed(2) + 'deg');
      });
      card.addEventListener('mouseleave', ()=>{
        inner.style.setProperty('--rx', '0deg');
        inner.style.setProperty('--ry', '0deg');
      });
    });

    /* ---------- Spotlight cards ---------- */
    document.querySelectorAll('.spotlight-card').forEach(card=>{
      card.addEventListener('mousemove', (e)=>{
        const r = card.getBoundingClientRect();
        card.style.setProperty('--mx', (e.clientX - r.left) + 'px');
        card.style.setProperty('--my', (e.clientY - r.top) + 'px');
      });
    });

    /* ---------- Magnetic buttons ---------- */
    document.querySelectorAll('.magnetic').forEach(btn=>{
      btn.addEventListener('mousemove', (e)=>{
        const r = btn.getBoundingClientRect();
        const mx = (e.clientX - r.left - r.width/2) * 0.28;
        const my = (e.clientY - r.top - r.height/2) * 0.35;
        btn.style.transform = `translate(${mx}px, ${my}px)`;
      });
      btn.addEventListener('mouseleave', ()=>{ btn.style.transform = 'translate(0,0)'; });
    });
  }

  /* ---------- Contact form (demo submit) ---------- */
  const form = document.querySelector('.contact-form');
  if(form){
    form.addEventListener('submit', (e)=>{
      e.preventDefault();
      const btn = form.querySelector('button[type="submit"]');
      const original = btn.textContent;
      btn.textContent = 'Message sent —';
      btn.disabled = true;
      setTimeout(()=>{ btn.textContent = original; btn.disabled = false; form.reset(); }, 2200);
    });
  }

})();
